﻿using System.ComponentModel.DataAnnotations;

namespace InleveropdrGijs.Models
{
    public class Foto
    {
        [Key]
        public int FotoID { get; set; }
        public List<Camera> CameraID { get; set; }
        public int AantalFotos { get; set; }

        
    }
}
