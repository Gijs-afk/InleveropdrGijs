﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace InleveropdrGijs.Models
{
    public class Account
    {
        [Key]
        public int Id { get; set; }

        [Required, DisplayName("klantNaam"), StringLength(100)]
        public string klantNaam { get; set; }

        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        public int AantalVrienden { get; set; }
        public int Punten { get; set; }



    }
}
