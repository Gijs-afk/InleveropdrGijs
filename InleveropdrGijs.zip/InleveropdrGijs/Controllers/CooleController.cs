﻿using Microsoft.AspNetCore.Mvc;
using InleveropdrGijs.Models;
using InleveropdrGijs.Data;
using Microsoft.EntityFrameworkCore;

namespace InleveropdrGijs.Controllers
{
    public class CooleController : Controller
    {
        private readonly AppDbContext database;

        public CooleController(AppDbContext database)
        {
            this.database = database;
        }

        public IActionResult Index()
        {
            IEnumerable<Account> objAccountList = database.InleveropdrGijs;
            return View(objAccountList);
        }
    }
}
